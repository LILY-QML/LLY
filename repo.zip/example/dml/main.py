# example/dml/main.py

import os
import sys
import threading  # Importiere threading, um den Hauptthread zu identifizieren
import argparse    # Importiere argparse für Kommandozeilenargumente

# Füge den Pfad zum Hauptverzeichnis hinzu, damit die `lly`-Module gefunden werden können
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(current_dir, '..', '..'))
sys.path.insert(0, parent_dir)

# Debug-Ausgabe der sys.path (optional, zur Fehlerbehebung)
print("sys.path:")
for p in sys.path:
    print(p)

# Jetzt, nachdem sys.path angepasst wurde, importiere die Module
try:
    from lly.core.thread import ThreadMonitor  # Importiere ThreadMonitor aus lly.core.thread
    from src.dml import DML  # Importiere die DML-Klasse aus src/dml.py
except ModuleNotFoundError as e:
    print(f"ImportError: {e}")
    sys.exit(1)

def run_test_mode():
    """
    Führt den Testmodus aus, um sicherzustellen, dass die wesentlichen Funktionen korrekt arbeiten.
    """
    print("\n=== Testmodus aktiviert ===\n")
    
    # Initialisiere eine DML-Instanz mit einem Testdatenpfad oder Mock-Daten
    test_data_path = os.path.join(current_dir, 'var', 'test_data.json')
    
    # Erstelle eine Test-dml.json Datei, falls sie nicht existiert
    if not os.path.exists(test_data_path):
        test_data = {
            "activation_matrices": [
                {
                    "name": "TestMatrix1",
                    "matrix": [
                        [0.1, 0.2, 0.3],
                        [0.4, 0.5, 0.6]
                    ],
                    "target_state": [1, 0]
                }
            ]
        }
        os.makedirs(os.path.dirname(test_data_path), exist_ok=True)
        with open(test_data_path, 'w') as f:
            import json
            json.dump(test_data, f, indent=4)
        print(f"Erstellte Testdaten unter {test_data_path}")
    
    # Initialisiere die DML-Klasse mit den Testdaten
    dml = DML(data_path=test_data_path)
    
    # Test 1: Überprüfe, ob die Daten korrekt geladen wurden
    if not dml.activation_matrices:
        print("Fehler: Aktivierungsmatrizen wurden nicht korrekt geladen.")
        return
    else:
        print("Test 1 bestanden: Aktivierungsmatrizen wurden korrekt geladen.")
    
    # Test 2: Erstelle einen Circuit und überprüfe die Trainingsphasen
    circuit, training_phases = dml.create()
    if circuit is None or training_phases is None:
        print("Fehler: Circuit konnte nicht erstellt werden.")
        return
    else:
        print("Test 2 bestanden: Circuit wurde erfolgreich erstellt.")
    
    # Test 3: Führe eine Messung durch und überprüfe die Ergebnisse
    measurement_results = dml.measure(training_matrix=training_phases, shots=100, activation_matrix=dml.activation_matrices[0]["matrix"])
    if not measurement_results:
        print("Fehler: Messung hat keine Ergebnisse geliefert.")
        return
    else:
        print("Test 3 bestanden: Messung wurde erfolgreich durchgeführt.")
    
    # Test 4: Speichere die Trainingsmatrix und überprüfe die Datei
    test_save_folder = os.path.join(current_dir, 'test_saved_matrices')
    dml.save_training_matrix(training_matrix=training_phases, folder_path=test_save_folder)
    saved_files = os.listdir(test_save_folder)
    if not saved_files:
        print("Fehler: Trainingsmatrix wurde nicht gespeichert.")
        return
    else:
        print(f"Test 4 bestanden: Trainingsmatrix wurde erfolgreich in '{test_save_folder}' gespeichert.")
    
    # Test 5: Führe eine Optimierung mit reduzierten Parametern durch
    print("\nStarte eine schnelle Optimierung für Testzwecke...")
    dml.optimize(
        optimizer='adam',
        optimized_param={'learning_rate': 0.001},
        shots=1000,         # Reduzierte Anzahl der Shots
        iterations=10000,     # Reduzierte Anzahl der Iterationen
        end_value=0.95    # Niedrigerer Schwellenwert
    )
    print("Test 5 abgeschlossen: Optimierung durchgeführt.")
    
    # Test 6: Generiere eine PDF und überprüfe deren Existenz
    pdf_report = dml.visual.pdf_filename
    if os.path.exists(pdf_report):
        print(f"Test 6 bestanden: PDF-Bericht '{pdf_report}' wurde erfolgreich erstellt.")
    else:
        print("Fehler: PDF-Bericht wurde nicht erstellt.")
    
    # Cleanup: Entferne die Testdaten und gespeicherten Matrizen
    try:
        os.remove(test_data_path)
        import shutil
        shutil.rmtree(test_save_folder)
        print("\nBereinigung abgeschlossen: Testdaten und temporäre Dateien wurden entfernt.")
    except Exception as e:
        print(f"Warnung: Fehler bei der Bereinigung der Testdaten: {e}")
    
    print("\n=== Testmodus abgeschlossen ===\n")

def main():
    # Parse Kommandozeilenargumente
    parser = argparse.ArgumentParser(description="DML Hauptprogramm mit optionalem Testmodus.")
    parser.add_argument('-t', '--test', action='store_true', help='Führe das Programm im Testmodus aus.')
    args = parser.parse_args()
    
    if args.test:
        run_test_mode()
        sys.exit(0)  # Beende das Programm nach dem Testmodus
    
    # Initialisiere den ThreadMonitor
    thread_monitor = ThreadMonitor()
    
    # Identifiziere den Hauptthread
    main_thread_id = threading.get_ident()
    
    # Logge den Start des Hauptthreads
    thread_monitor.log_thread_start(main_thread_id, "Main Execution")
    
    try:
        # Pfad zur data.json Datei
        data_json_path = os.path.join(current_dir, 'var', 'data.json')
    
        # Initialisiere die DML-Klasse (führt automatisch `check` aus)
        dml = DML(data_path=data_json_path)
    
        # Erstelle den Circuit und die Trainings-Phasengatter-Matrix
        circuit, training_phases_matrix = dml.create()
    
        if circuit is None:
            print("Fehler beim Erstellen des Circuit.")
            sys.exit(1)
    
        # Ausgabe des Circuit
        print("\nErstellter Circuit:")
        print(circuit)  # Passe dies an die tatsächliche Implementierung der Circuit-Klasse an
    
        # Ausgabe der generierten Trainings-Phasengatter-Matrix
        print("\nGenerierte Trainings-Phasengatter-Matrix:")
        for qubit_idx, qubit_gates in enumerate(training_phases_matrix):
            print(f"Qubit {qubit_idx + 1}:")
            for gate_idx, gate in enumerate(qubit_gates):
                print(f"  Gate {gate_idx + 1}: {gate}")
    
        # Messung der Trainingsmatrix mit einer Aktivierungsmatrix
        print("\nFühre Messung durch...")
        if dml.activation_matrices:
            activation_matrix = dml.activation_matrices[0]["matrix"]  # Beispiel: Erste Aktivierungsmatrix
            shots = 1000  # Anzahl der Shots für die Messung
            measurement_results = dml.measure(training_matrix=training_phases_matrix, shots=shots, activation_matrix=activation_matrix)
    
            # Ausgabe der Messresultate
            print("\nMessresultate:")
            for state, count in measurement_results.items():
                print(f"State: {state}, Count: {count}")
    
        # Speichern der Trainingsmatrix in einem Ordner
        save_folder = os.path.join(current_dir, 'saved_matrices')
        print(f"\nSpeichere Trainingsmatrix in: {save_folder}")
        dml.save_training_matrix(training_matrix=training_phases_matrix, folder_path=save_folder)
    
        # Führe die Optimierung durch
        optimizer_type = 'adam'  # Beispiel: 'adam'
        optimizer_params = {'learning_rate': 0.001}  # Beispiel-Parameter für Adam
        shots = 1000
        iterations = 10000
        end_value = 0.95  # Optionaler Schwellenwert
    
        print("\nStarte Optimierungsprozess...")
        dml.optimize(
            optimizer=optimizer_type,
            optimized_param=optimizer_params,
            shots=shots,
            iterations=iterations,
            end_value=end_value
        )
    
        # Nach der Optimierung, lade die optimierten Phasen erneut
        dml.load_data()
        circuit, training_phases_matrix = dml.create()
    
        if circuit is None:
            print("Fehler beim Erstellen des Circuit nach der Optimierung.")
            sys.exit(1)
    
        # Ausgabe des optimierten Circuit
        print("\nOptimierter Circuit:")
        print(circuit)  # Passe dies an die tatsächliche Implementierung der Circuit-Klasse an
    
        # Ausgabe der optimierten Trainings-Phasengatter-Matrix
        print("\nOptimierte Trainings-Phasengatter-Matrix:")
        for qubit_idx, qubit_gates in enumerate(training_phases_matrix):
            print(f"Qubit {qubit_idx + 1}:")
            for gate_idx, gate in enumerate(qubit_gates):
                print(f"  Gate {gate_idx + 1}: {gate}")
    
    finally:
        # Logge das Ende des Hauptthreads
        thread_monitor.log_thread_end(main_thread_id)
        
        # Generiere den PDF-Bericht der Thread-Aktivitäten
        thread_monitor.generate_pdf_report()
    
        # Optional: Ausgabe der Thread-Daten im Terminal
        print("\nCurrent Thread Activity Overview:")
        print(thread_monitor)

if __name__ == "__main__":
    main()
